<?php

namespace App\Http\Controllers;

use App\Models\Santri;
use App\Models\Ortu;
use App\Models\User;
use App\Models\Admin;
use App\Models\JadwalKegiatan;
use App\Models\Laporan;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Models\Notifikasi;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;

class SantriController extends Controller
{
    public function dashboard()
    {
        $userId = session('user_id');
        $profile = DB::table('users')
            ->join('santri', 'santri.user_id', '=', 'users.id')
            ->where('users.id', $userId)
            ->select('users.id as user_id', 'users.username', 'santri.nama', 'santri.foto')
            ->first();
        $role = session('role');


        $totalJadwal = JadwalKegiatan::count();
        $jumlahUpload = Laporan::where('user_id', $userId)->count();
        $jumlahTidakUpload = $totalJadwal - $jumlahUpload;

        return view('santri.dashboard', compact('role', 'profile', 'jumlahUpload', 'jumlahTidakUpload'));
    }
    public function showLaporan()
    {
        if (!session()->has('role')) {
            return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userId = session('user_id');

        $profile = DB::table('users')
            ->join('santri', 'santri.user_id', '=', 'users.id')
            ->where('users.id', $userId)
            ->select('users.id as user_id', 'users.username', 'santri.nama', 'santri.foto', 'santri.id as santri_id')
            ->first();

        $santriId = $profile->santri_id;

        $role = session('role');
        $jadwals = JadwalKegiatan::whereBetween('tanggal', [
            Carbon::today()->toDateString(),
            Carbon::tomorrow()->toDateString()
        ])->orderBy('tanggal', 'DESC')
            ->orderBy('waktu_mulai', 'DESC')
            ->get();

        $laporans = Laporan::where('santri_id', $santriId)->get()->keyBy('jadwal_id');

        return view('santri.laporan', compact('role', 'profile', 'jadwals', 'laporans'));
    }

    public function uploadLaporan(Request $request)
    {
        $request->validate([
            'jadwal_id' => 'required|exists:jadwal_kegiatan,id',
            'bukti_laporan' => 'required|file|mimes:jpg,jpeg,png,pdf|max:2048'
        ]);
        $path = $request->file('bukti_laporan')->store('laporan_santri', 'public');
        $userId = session('user_id');
        $santri = Santri::where('user_id', $userId)->first();
        if (!$santri) {
            return redirect()->route('santri.laporan')->with('error', 'Santri tidak ditemukan.');
        }
        $laporan = Laporan::where('santri_id', $santri->id)
            ->where('jadwal_id', $request->jadwal_id)
            ->first();
        if ($laporan) {
            if ($laporan->bukti_laporan && Storage::disk('public')->exists($laporan->bukti_laporan)) {
                Storage::disk('public')->delete($laporan->bukti_laporan);
            }
            $laporan->update([
                'bukti_laporan' => $path
            ]);
        } else {
            Laporan::create([
                'santri_id' => $santri->id,
                'jadwal_id' => $request->jadwal_id,
                'bukti_laporan' => $path
            ]);
        }
        return redirect()->route('santri.laporan')->with('success', 'Laporan berhasil diupload.');
    }
    public function update(Request $request)
    {
        $request->validate([
            'laporan_id' => 'required|exists:laporan,id',
            'bukti_laporan' => 'required|file|mimes:jpg,jpeg,png,pdf|max:2048',
        ]);

        $laporan = Laporan::find($request->laporan_id);

        if ($laporan->bukti_laporan && Storage::exists('public/' . $laporan->bukti_laporan)) {
            Storage::delete('public/' . $laporan->bukti_laporan);
        }

        $file = $request->file('bukti_laporan');
        $path = $file->store('bukti_laporan', 'public');

        $laporan->bukti_laporan = $path;
        $laporan->save();

        return back()->with('success', 'Laporan berhasil diperbarui.');
    }

    public function showRekapLaporan()
    {
        if (!session()->has('role')) {
            return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userId = session('user_id');

        $profile = DB::table('users')
            ->join('santri', 'santri.user_id', '=', 'users.id')
            ->where('users.id', $userId)
            ->select('users.id as user_id', 'users.username', 'santri.nama', 'santri.foto', 'santri.id as santri_id')
            ->first();

        $santriId = $profile->santri_id;

        $role = session('role');
        $jadwals = JadwalKegiatan::orderBy('tanggal', 'DESC')
            ->orderBy('waktu_mulai', 'DESC')
            ->get();


        $laporans = Laporan::where('santri_id', $santriId)->get()->keyBy('jadwal_id');

        return view('santri.rekapLaporan', compact('role', 'profile', 'jadwals', 'laporans'));
    }

    public function typeLaporan(Request $request)
    {
        if (!session()->has('role')) {
            return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        $userId = session('user_id');

        $profile = DB::table('users')
            ->join('santri', 'santri.user_id', '=', 'users.id')
            ->where('users.id', $userId)
            ->select('users.id as user_id', 'users.username', 'santri.nama', 'santri.foto', 'santri.id as santri_id')
            ->first();

        $santriId = $profile->santri_id;

        $role = session('role');
        $jadwals = JadwalKegiatan::orderBy('tanggal', 'DESC')
            ->orderBy('waktu_mulai', 'DESC')
            ->get();

        $laporans = Laporan::where('santri_id', $santriId)->get()->keyBy('jadwal_id');

        $type = $request->query('type');
        if ($type === 'uploaded') {
            $jadwals = $jadwals->filter(fn($jadwal) => isset($laporans[$jadwal->id]));
        } elseif ($type === 'not_uploaded') {
            $jadwals = $jadwals->filter(fn($jadwal) => !isset($laporans[$jadwal->id]));
        }

        return view('santri.upload-tidakLaporan', compact('role', 'profile', 'jadwals', 'laporans', 'type'));
    }
}
