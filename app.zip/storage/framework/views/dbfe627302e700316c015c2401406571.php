<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- CSS -->
  <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/images/logo.svg')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('dist/css/adminlte.css')); ?>">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/2.3.2/css/dataTables.dataTables.min.css">
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <?php echo $__env->yieldContent('style'); ?>
  <style>
    .text-wrap {
      white-space: normal !important;
      word-break: break-word;
    }
  </style>
</head>

<body class="layout-fixed sidebar-expand-lg sidebar-open bg-body-tertiary">
  <div class="app-wrapper">

    
    <?php echo $__env->make('partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="app-main">
      <?php echo $__env->yieldContent('content'); ?>
    </main>

    
    <footer class="app-footer">
      <strong>
        Copyright &copy; <?php echo e(date('Y')); ?>

      </strong> All rights reserved.
    </footer>

  </div>

  


  <script
    src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"
    crossorigin="anonymous"></script>
  <script
    src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
    crossorigin="anonymous"></script>
  <script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.min.js"
    crossorigin="anonymous"></script>
  <script src="<?php echo e(asset('dist/js/adminlte.js')); ?>"></script>
  <script src="https://cdn.datatables.net/2.3.2/js/dataTables.min.js"></script>

  <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\monitoring-santri\resources\views/layouts/app.blade.php ENDPATH**/ ?>