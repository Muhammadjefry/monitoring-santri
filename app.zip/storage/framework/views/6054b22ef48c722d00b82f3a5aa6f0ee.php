<aside class="app-sidebar bg-primary shadow" data-bs-theme="dark">
  <div class="sidebar-brand">
    <a href="#" class="brand-link">

      <span class="brand-text m-0 fw-light text-white">
        <img src="<?php echo e(asset('assets/images/logo.svg')); ?>" style="width:50px" alt="Logo">
        <span>Monitoring Santri</span>
      </span>
    </a>
  </div>
  <div class="sidebar-wrapper">
    <nav class="mt-2">
      <ul
        class="nav sidebar-menu flex-column"
        data-lte-toggle="treeview"
        role="navigation"
        aria-label="Main navigation"
        data-accordion="false"
        id="navigation">

        <li class="nav-header">Home</li>
        <li class="nav-item">
          <?php if($role === 'ADMINISTRATOR'): ?>
          <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-link text-white <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
            <i class="nav-icon bi bi-house"></i>
            <p>Dashboard</p>
          </a>
          <?php elseif($role === 'SANTRI'): ?>
          <a href="<?php echo e(route('santri.dashboard')); ?>" class="nav-link text-white <?php echo e(request()->routeIs('santri.dashboard') ? 'active' : ''); ?>">
            <i class="nav-icon bi bi-house"></i>
            <p>Dashboard</p>
          </a>
          <?php elseif($role === 'ORANG TUA'): ?>
          <a href="<?php echo e(route('ortu.dashboard')); ?>" class="nav-link text-white <?php echo e(request()->routeIs('ortu.dashboard') ? 'active' : ''); ?>">
            <i class="nav-icon bi bi-house"></i>
            <p>Dashboard</p>
          </a>
          <?php endif; ?>
        </li>
        <li class="nav-header">Menu Utama</li>
        <li class="nav-item">

          <?php if($role === 'ADMINISTRATOR'): ?>
          <a href="<?php echo e(route('admin.jadwal')); ?>" class="nav-link text-white <?php echo e(request()->routeIs('admin.jadwal') ? 'active' : ''); ?>">
            <i class="nav-icon bi bi-calendar"></i>
            <p>Jadwal Kegiatan</p>
          </a>
          <?php elseif($role === 'SANTRI'): ?>
          <a href="<?php echo e(route('santri.jadwal')); ?>" class="nav-link text-white <?php echo e(request()->routeIs('santri.jadwal') ? 'active' : ''); ?>">
            <i class="nav-icon bi bi-calendar"></i>
            <p>Jadwal Kegiatan</p>
          </a>
          <?php elseif($role === 'ORANG TUA'): ?>
          <a href="<?php echo e(route('ortu.jadwal')); ?>" class="nav-link text-white <?php echo e(request()->routeIs('ortu.jadwal') ? 'active' : ''); ?>">
            <i class="nav-icon bi bi-calendar"></i>
            <p>Jadwal Kegiatan</p>
          </a>
          <?php endif; ?>


        </li>
        <li class="nav-item">

          <?php if($role === 'ADMINISTRATOR'): ?>
          <a href="<?php echo e(route('laporanMasuk')); ?>" class="nav-link text-white <?php echo e(request()->routeIs('laporanMasuk', 'admin.rekapLaporan') ? 'active' : ''); ?>">
            <i class="nav-icon bi bi-box-arrow-in-right"></i>
            <p>Laporan Masuk</p>
          </a>
          <?php elseif($role === 'SANTRI'): ?>
          <a href="<?php echo e(route('santri.laporan')); ?>"
            class="nav-link text-white <?php echo e(request()->routeIs('santri.laporan', 'santri.rekapLaporan') ? 'active' : ''); ?>">
            <i class="nav-icon bi bi-box-arrow-in-right"></i>
            <p>Isi Laporan</p>
          </a>

          <?php elseif($role === 'ORANG TUA'): ?>
          <a href="<?php echo e(route('ortu.laporan')); ?>" class="nav-link text-white <?php echo e(request()->routeIs('ortu.laporan') ? 'active' : ''); ?>">
            <i class="nav-icon bi bi-box-arrow-in-right"></i>
            <p>Laporan Santri</p>
          </a>
          <?php endif; ?>

        </li>
        <li class="nav-header">Users</li>

        <?php if($role === 'ADMINISTRATOR'): ?>
        <li class="nav-item <?php echo e(request()->routeIs('admin.santri') || request()->routeIs('admin.ortu') ? 'menu-open' : ''); ?>">
          <a href="#" class="nav-link  text-white <?php echo e(request()->routeIs('admin.santri') || request()->routeIs('admin.ortu') ? 'active' : ''); ?>">
            <i class="nav-icon bi bi-people"></i>
            <p>
              Akun Pengguna
              <i class="nav-arrow bi bi-chevron-right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?php echo e(route('admin.santri')); ?>" class="nav-link text-white <?php echo e(request()->routeIs('admin.santri') ? 'active' : ''); ?>">
                <i class="nav-icon bi bi-circle"></i>
                <p>Santri</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?php echo e(route('admin.ortu')); ?>" class="nav-link  text-white <?php echo e(request()->routeIs('admin.ortu') ? 'active' : ''); ?>">
                <i class="nav-icon bi bi-circle"></i>
                <p>Orang tua</p>
              </a>
            </li>
          </ul>
        </li>
        <?php endif; ?>


        <li class="nav-item">
          <a href="<?php echo e(route('profile')); ?>" class="nav-link text-white <?php echo e(request()->routeIs('profile') ? 'active' : ''); ?>">
            <i class="nav-icon bi bi-person"></i>
            <p>Profile</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="<?php echo e(route('logout')); ?>" onclick="return confirm('Yakin ingin logout?')" class="nav-link text-white">
            <i class="nav-icon bi bi-box-arrow-in-right"></i>
            <p>Logout</p>
          </a>
        </li>

      </ul>
    </nav>
  </div>
</aside><?php /**PATH C:\xampp\htdocs\monitoring-santri\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>