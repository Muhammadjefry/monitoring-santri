<nav class="app-header navbar navbar-expand bg-body">
  <div class="container-fluid">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a
          class="nav-link"
          data-lte-toggle="sidebar"
          href="#"
          role="button">
          <i class="bi bi-list"></i>
        </a>
      </li>

    </ul>
    <ul class="navbar-nav ms-auto">
      <?php if($role === 'SANTRI' || $role === 'ORANG TUA'): ?>

      <?php
      $unreadCount = $notifications->where('is_read', false)->count();
      ?>

      <li class="nav-item dropdown">
        <a class="nav-link" data-bs-toggle="dropdown" href="#">
          <i class="bi bi-bell-fill"></i>
          <?php if($unreadCount > 0): ?>
          <span class="navbar-badge badge text-bg-warning"><?php echo e($unreadCount); ?></span>
          <?php endif; ?>
        </a>

        <div class="dropdown-menu dropdown-menu-xl dropdown-menu-end">
          <span class="dropdown-item dropdown-header">
            <?php echo e($unreadCount); ?> Notifikasi Baru
          </span>

          <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="dropdown-divider"></div>
          <a href="#" class="dropdown-item">
            <i class="bi bi-info-circle me-2 <?php echo e($notif->is_read ? 'text-muted' : 'text-primary'); ?>"></i>
            <strong><?php echo e($notif->judul); ?></strong>
            <span class="float-end text-secondary fs-7">
              <?php echo e($notif->created_at->diffForHumans()); ?>

            </span>
            <div class="small text-muted text-wrap">
              <?php echo e($notif->pesan); ?>

            </div>
          </a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <div class="dropdown-divider"></div>
          <span class="dropdown-item text-muted text-center">Tidak ada notifikasi</span>
          <?php endif; ?>

          <div class="dropdown-divider"></div>
          <form method="POST" action="<?php echo e(route('notifikasi.baca_semua')); ?>" class="dropdown-item text-center">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-sm btn-link">Tandai Semua Dibaca</button>
          </form>
        </div>
      </li>
      <?php endif; ?>



      <li class="nav-item dropdown user-menu">
        <a
          href="#"
          class="nav-link dropdown-toggle"
          data-bs-toggle="dropdown">

          <?php if(!is_null($profile) && $profile->foto): ?>
          <img src="<?php echo e(asset('storage/' . $profile->foto)); ?>"
            class="user-image rounded-circle shadow"
            alt="User Image">
          <?php else: ?>
          <svg class="user-image rounded-circle shadow"
            alt="User Image" viewBox="0 0 24 24" fill="none" stroke="#888" stroke-width="1.5"
            stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="8" r="4" />
            <path d="M4 20c0-4 4-7 8-7s8 3 8 7" />
          </svg>
          <?php endif; ?>

          <?php
          use App\Models\Admin;
          use App\Models\Santri;
          use App\Models\Ortu;

          $userId = session('user_id');
          $role = session('role');
          $nama = 'Pengguna';

          if ($role === 'ADMINISTRATOR') {
          $admin = Admin::where('user_id', $userId)->first();
          $nama = $admin?->nama ?? 'Admin';
          } elseif ($role === 'SANTRI') {
          $santri = Santri::where('user_id', $userId)->first();
          $nama = $santri?->nama ?? 'Santri';
          } elseif ($role === 'ORANG TUA') {
          $ortu = Ortu::where('user_id', $userId)->first();
          $nama = $ortu?->nama ?? 'Orang Tua';
          }

          ?>

          <?php if(session()->has('user_id')): ?>
          <span class="d-none d-md-inline"><?php echo e($nama); ?></span>
          <?php else: ?>
          <span class="text-danger">Belum login</span>
          <?php endif; ?>

        </a>
        <ul class="dropdown-menu dropdown-menu-xl dropdown-menu-end">
          <li class="user-header text-bg-primary">

            <?php if(!is_null($profile) && $profile->foto): ?>
            <img src="<?php echo e(asset('storage/' . $profile->foto)); ?>"
              class="rounded-circle shadow"
              alt="User Image">
            <?php else: ?>
            <svg style="width: 50%;" class="rounded-circle shadow"
              alt="User Image" viewBox="0 0 24 24" fill="none" stroke="#888" stroke-width="1.5"
              stroke-linecap="round" stroke-linejoin="round">
              <circle cx="12" cy="8" r="4" />
              <path d="M4 20c0-4 4-7 8-7s8 3 8 7" />
            </svg>
            <?php endif; ?>
            <p>
              <?php if(session()->has('user_id')): ?>
              <span class="d-none d-md-inline"><?php echo e($nama); ?></span>
              <small><span class="d-none d-md-inline"><?php echo e($role); ?></span></small>
              <?php else: ?>
              <span class="text-danger">Belum login</span>
              <?php endif; ?>
            </p>
          </li>
          <li class="user-footer text-center">
            <a href="<?php echo e(route('profile')); ?>" class="btn btn-default">Profile</a>
            <a href="<?php echo e(route('logout')); ?>" onclick="return confirm('Yakin ingin logout?')" class="btn btn-default">Log out</a>
          </li>
        </ul>
      </li>
    </ul>
  </div>
</nav><?php /**PATH C:\xampp\htdocs\monitoring-santri\resources\views/partials/navbar.blade.php ENDPATH**/ ?>