

<?php $__env->startSection('title', 'Laporan Kegiatan'); ?>

<?php $__env->startSection('style'); ?>
<style>
  /* Alert Style */
  .alert-succees {
    position: relative;
    opacity: 0;
    transform: translateY(-100%);
    transition: all 0.5s ease-in-out;

    background-color: rgb(163, 207, 186.6);
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    padding: 15px;
    color: #ffffffff;
    border-radius: 8px;
    margin-bottom: 20px;
  }

  .alert-succees.slide-down.show {
    opacity: 1;
    transform: translateY(0);
  }

  .alert-danger {
    position: relative;
    opacity: 0;
    transform: translateY(-100%);
    transition: all 0.5s ease-in-out;

    background-color: rgb(241, 174.2, 180.6);
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    padding: 15px;
    color: #92400e;
    border-radius: 8px;
    margin-bottom: 20px;
  }

  .alert-danger.slide-down.show {
    opacity: 1;
    transform: translateY(0);
  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="app-content-header">
  <div class="container-fluid d-flex justify-content-between">
    <h5 class="mb-2">Laporan Masuk</h5>
    <h6>
      <?php echo e(\Carbon\Carbon::now()->translatedFormat('F, d-m-Y')); ?>

    </h6>
  </div>
</div>

<div class="row text-center mb-5">
  <div class="col-md-12">
    <a href="<?php echo e(route('admin.rekapLaporan')); ?>" class="btn btn-primary m-0">
      Rekap Laporan
    </a>
  </div>
</div>

<div class="app-content">
  <div class="container-fluid">

    <div class="row">
      <div class="col-md-12">
        <?php if(session('success')): ?>
        <div class="d-flex justify-content-between alertt alert-succees slide-down" id="alert-succees">
          <div>
            <h5><i class="bi bi-check"></i> Sukses!</h5>
            <?php echo e(session('success')); ?>

          </div>
          <div>
            <button class="close d-block btn" onclick="close_alert()">×</button>
          </div>
        </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
        <div class="d-flex justify-content-between alertt alert-danger slide-down" id="alert-danger">
          <div>
            <h5><i class="bi bi-ban"></i> Gagal!</h5>
            <?php echo e(session('error')); ?>

          </div>
          <div>
            <button class="close d-block btn" onclick="close_alert()">×</button>
          </div>
        </div>
        <?php endif; ?>

        <div class="card mb-4">

          <div class="card-body">
            <table id="myTable" class="table table-bordered">
              <thead>

                <tr>
                  <th style="width: 10px">#</th>
                  <th>Nama</th>
                  <th>Nama Kegiatan</th>
                  <th>Foto/Dokumentasi Laporan</th>
                  <th>Waktu Submit Laporan</th>


                </tr>
              </thead>

              <tbody>
                <?php $__currentLoopData = $laporans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $laporan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($index + 1); ?></td>
                  <td><?php echo e($laporan->santri->nama ?? '-'); ?></td>
                  <td><?php echo e($laporan->jadwal->judul_kegiatan ?? '-'); ?></td>
                  <td>
                    <?php if($laporan->bukti_laporan): ?>
                    <?php
                    $filePath = asset('storage/' . $laporan->bukti_laporan);
                    $ext = strtolower(pathinfo($laporan->bukti_laporan, PATHINFO_EXTENSION));
                    $isImage = in_array($ext, ['jpg', 'jpeg', 'png']);
                    ?>
                    <img src="<?php echo e($filePath); ?>" alt="Bukti" style="max-width: 100px; cursor: pointer;" onclick="previewModal('<?php echo e($filePath); ?>')">
                    <?php else: ?>
                    Tidak ada bukti
                    <?php endif; ?>
                  </td>


                  <td><?php echo e(\Carbon\Carbon::parse($laporan->updated_at)->format('d-m-Y H:i')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>




            </table>
          </div>
        </div>


      </div>
    </div>
  </div>
</div>

<div class=" modal fade" id="modalPreview" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-body text-center">
        <img id="modalImage" src="" class="img-fluid" alt="Preview">
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
  let table = new DataTable('#myTable');

  function close_alert() {
    $('.alertt').remove();
  }

  function previewModal(src) {
    document.getElementById('modalImage').src = src;
    $('#modalPreview').modal('show');
  }

  window.addEventListener('DOMContentLoaded', () => {
    const alert1 = document.getElementById('alert-succees');
    const alert2 = document.getElementById('alert-danger');

    if (alert1) {
      setTimeout(() => {
        alert1.classList.add('show');
      }, 100);

      setTimeout(() => {
        alert1.classList.remove('show');

        setTimeout(() => {
          alert1.remove();
        }, 500);
      }, 4000);
    } else if (alert2) {
      setTimeout(() => {
        alert2.classList.add('show');
      }, 100);

      setTimeout(() => {
        alert2.classList.remove('show');

        setTimeout(() => {
          alert2.remove();
        }, 500);
      }, 4000);
    }
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\monitoring-santri\resources\views/admin/laporan.blade.php ENDPATH**/ ?>