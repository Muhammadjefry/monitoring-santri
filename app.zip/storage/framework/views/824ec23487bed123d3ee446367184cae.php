<!doctype html>
<html>

<head>
  <meta charset="utf-8">
  <style>
    body {
      font-family: DejaVu Sans, sans-serif;
      font-size: 12px
    }

    .header {
      margin-bottom: 10px
    }

    table {
      width: 100%;
      border-collapse: collapse
    }

    th,
    td {
      border: 1px solid #ddd;
      padding: 6px;
      text-align: left
    }
  </style>
</head>

<body>
  <div class="header">
    <h3>Rekap Laporan Santri</h3>
    <p>Nama Santri: <?php echo e($santri->nama_santri ?? '-'); ?></p>
    <p>Nama Orangtua: <?php echo e($santri->nama_ortu ?? '-'); ?> — <?php echo e($santri->no_hp_ortu ?? '-'); ?></p>
    <hr>
  </div>

  <table>
    <thead>
      <tr>
        <th>No</th>
        <th>Tanggal</th>
        <th>Waktu</th>
        <th>Kegiatan</th>
        <th>Status</th>
        <th>Uploaded At</th>
      </tr>
    </thead>



    <tbody>
      <?php
      date_default_timezone_set('Asia/Jakarta');
      ?>

      <?php $__currentLoopData = $jadwals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php
      $laporan = $laporans[$jadwal->id] ?? null;

      $waktuMulaiFix = str_replace('.', ':', $jadwal->waktu_mulai);
      $waktuSelesaiFix = str_replace('.', ':', $jadwal->waktu_selesai);

      if (preg_match('/^\d{1,2}$/', $waktuMulaiFix)) {
      $waktuMulaiFix .= ':00:00';
      } elseif (preg_match('/^\d{1,2}:\d{1,2}$/', $waktuMulaiFix)) {
      $waktuMulaiFix .= ':00';
      }

      if (preg_match('/^\d{1,2}$/', $waktuSelesaiFix)) {
      $waktuSelesaiFix .= ':00:00';
      } elseif (preg_match('/^\d{1,2}:\d{1,2}$/', $waktuSelesaiFix)) {
      $waktuSelesaiFix .= ':00';
      }

      $mulai = \Carbon\Carbon::parse($jadwal->tanggal . ' ' . $waktuMulaiFix);
      $selesai = \Carbon\Carbon::parse($jadwal->tanggal . ' ' . $waktuSelesaiFix);

      $now = now()->seconds(0);

      $uploadTime = $laporan ? \Carbon\Carbon::parse($laporan->updated_at) : null;
      ?>

      <tr>
        <td><?php echo e($i + 1); ?></td>
        <td><?php echo e($jadwal->tanggal ? \Carbon\Carbon::parse($jadwal->tanggal)->format('d-m-Y') : '-'); ?></td>

        <td><?php echo e($mulai->format('H:i:s')); ?> - <?php echo e($selesai->format('H:i:s')); ?></td>

        <td><?php echo e($jadwal->judul_kegiatan); ?></td>
        <td>
          <?php if($laporan): ?>
          ✅ Sudah Upload
          <?php elseif($now->gt($selesai)): ?>
          ❌ Terlambat
          <?php else: ?>
          ⏳ Belum Upload
          <?php endif; ?>
        </td>

        <td><?php echo e($uploadTime ? $uploadTime->format('d-m-Y H:i:s') : '-'); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</body>

</html><?php /**PATH C:\xampp\htdocs\monitoring-santri\resources\views/admin/rekap.blade.php ENDPATH**/ ?>